
class MyGem
end

require 'my_gem/calculator'
require 'my_gem/my_gem'
